rm -rf /usr/share/tomcat8/webapps/FirstServletProject.war

rm -rf /usr/share/tomcat8/webapps/FirstServletProject