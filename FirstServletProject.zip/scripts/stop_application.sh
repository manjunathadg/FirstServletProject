curl –user tomcat:tomcat http://ec2-13-235-51-84.ap-south-1.compute.amazonaws.com:8080/manager/text/stop?path=/FirstServletProject
