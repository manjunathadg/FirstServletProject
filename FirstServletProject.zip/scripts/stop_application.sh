curl –user tomcat:tomcat http://ec2-13-233-85-182.ap-south-1.compute.amazonaws.com:8080/manager/text/stop?path=/FirstServletProject
