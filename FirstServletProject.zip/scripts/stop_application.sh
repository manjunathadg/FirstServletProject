curl –user tomcat:tomcat http://13.233.85.182:8080/manager/text/stop?path=/FirstServletProject
